public interface Exchangeable {
    double MM = 1.25;
    double SS = 0.55;
    double JJ = 2.00;
    
    public void exchange(Currency other, double amount);
}
